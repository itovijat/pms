person id show

<?php
if( !isset($_REQUEST['id'])){

    echo "<script> window.history.back(); </script>";
    die();


}
?>